var counter = 0;
function changeBG(){
    var imgs = [
        "url(http://drive.google.com/uc?export=view&id=1PXPemTvx8_9PVJBfXHeWXXodKw1z02_b)",
        "url(http://drive.google.com/uc?export=view&id=1OCBRltQZjMBsIgy1h5lmXgU-WbpdZb9X)",
        "url(http://drive.google.com/uc?export=view&id=1hZx6WflvQd3uq0J0psPV1fKtP2pNwKwD)",
        "url(http://drive.google.com/uc?export=view&id=1y7Gk6PPbPfCxS9rDmFLl1NPvqJtIsAoD)",
        "url(http://drive.google.com/uc?export=view&id=1MagHcAbgocAExMkC8uM26azVX3Kxdgc4)",
        "url(http://drive.google.com/uc?export=view&id=11P82BwkHOoduDEZn8sZjt5GI_nA4QFPT)",
        "url(http://drive.google.com/uc?export=view&id=1CrXWtqf1DGaO2Acutd3YtxleTV3ag766)",
        "url(http://drive.google.com/uc?export=view&id=1h_x4oTWP6FLU5SHQAgklYm97jbXTc2O9)"
      ]
    
    if(counter === imgs.length) counter = 0;
    $("body").css("background-image", imgs[counter]);

    counter++;
}
  
  setInterval(changeBG, 4000);


